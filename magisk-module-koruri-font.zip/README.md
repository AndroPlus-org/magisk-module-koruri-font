#### Koruri Font

Koruri font patch for Japanese users.
This also replaces Roboto to Open Sans because Koruri is mixed font of Open Sans and M+ FONTS.
Only tested on Android 7.x Nougat ROM.

#### NOTICE

* You should use latest Magisk Manager to install this module. If you meet any problem under installation from Magisk Manager, please try to install it from recovery.

#### Credit & Support

* Author of Koruri - lindwurm (https://github.com/lindwurm)
* Any issue or pull request is welcome at [GitHub](https://github.com/Magisk-Modules-Repo/magisk-module-koruri-font).

## Change log

#### v05
* Updated template to 1700

#### v04
* Updated template to 1500

#### v03
* Fixed broken colon in lockscreen and ambient display clock

#### v02
* Changed template to 1400

#### v01
* Initial Release
